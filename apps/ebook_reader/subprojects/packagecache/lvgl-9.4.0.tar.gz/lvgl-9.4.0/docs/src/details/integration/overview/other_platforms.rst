.. _other_platforms:

=========================
Other Platforms and Tools
=========================

See :ref:`Integration <integration_index>` to see how to use LVGL on different
platforms.  There, you will find many platform-specific descriptions e.g. for ESP32,
Arduino, NXP, RT-Thread, NuttX, etc.


