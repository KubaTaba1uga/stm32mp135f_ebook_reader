.. _3rd_party_libraries:

===================
3rd-Party Libraries
===================


.. toctree::
    :maxdepth: 2

    arduino_esp_littlefs
    arduino_sd
    barcode
    bmp
    ffmpeg
    freetype
    frogfs
    fs
    gif
    gstreamer
    gltf
    lfs
    libjpeg_turbo
    libpng
    lodepng
    qrcode
    rle
    rlottie
    svg
    tiny_ttf
    tjpgd
