.. _main_modules:

============
Main Modules
============

.. toctree::
    :maxdepth: 2

    display/index
    indev/index
    color
    font
    image
    timer
    animation
    fs
    draw/index
