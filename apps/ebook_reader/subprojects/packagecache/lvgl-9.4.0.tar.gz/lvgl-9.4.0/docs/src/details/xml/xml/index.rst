.. _xml_main:

============
XML Overview
============


.. toctree::
    :maxdepth: 2

    overview
    syntax
    license
