===========
NXP G2D GPU
===========

API
***

.. API startswith:  lv_draw_g2d_
