.. _indev:

========================
Input devices (lv_indev)
========================

.. toctree::
    :maxdepth: 2

    overview
    pointer
    keypad
    encoder
    button
    groups
    gestures
