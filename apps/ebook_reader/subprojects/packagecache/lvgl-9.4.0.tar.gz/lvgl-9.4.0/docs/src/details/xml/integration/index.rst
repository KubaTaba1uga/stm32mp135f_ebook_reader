.. _editor_integration:

===========
Integration
===========

.. toctree::
    :class:    toctree-1-deep
    :maxdepth: 2

    c_code
    xml
