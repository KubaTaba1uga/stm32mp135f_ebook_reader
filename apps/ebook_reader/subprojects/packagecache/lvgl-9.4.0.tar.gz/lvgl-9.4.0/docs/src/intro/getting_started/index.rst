.. _getting_started:

===============
Getting started
===============

.. toctree::
    :maxdepth: 2

    learn_the_basics
    examples
    whats_next
